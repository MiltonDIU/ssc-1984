<?php
return [
    'site_title' => 'SSC-1984',
];
